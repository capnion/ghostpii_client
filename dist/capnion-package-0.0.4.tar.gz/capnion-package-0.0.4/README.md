# capnion_client_org
Python code for doing homomorphic computations on strings in conversation with Capnion's API.

Visit 
https://ghostpii.com/user-signup or https://ghostpii.com/organization-signup
to obtain an API token.

There are several demo notebooks located in the demo_notebooks folder of this repo briefly described below:

-Interactive_Documentation.ipynb shows some of the data structures available and some of their basic functionality.

-Demo.ipynb shows some record linkage operations as well as showing how to search the encrypted data and how to define your own functions to use on strings in the encrypted data.

-Distance_Calculations.ipynb and Quant_testing.ipynb both show functionality regarding the use of integers and floats in the encrypted data and some basic calculations.

-Organization_Sharing_owners.ipynb and Organization_Sharing_worker.ipynb show how encrypted data can be shared between users and how to add or restrict permissions on the shared data.

################
Some functions use Cython to increase performance.  Below are guidelines for installing Cython and compiling.

-sudo apt-get install build-essential
-sudo apt-get install cython3

Usage (creating pure Cython files):
-Cython language is nearly identical to python, files should be saved as *.pyx
-Once the example.pyx file has been made, a setup.py file is needed (example provided below)
	from distutils.core import setup
	from Cython.Build import cythonize

	setup(
    	   ext_modules = cythonize("example.pyx")
	)
-Run setup.py with following command "python3 setup.py build_ext --inplace"
-this will compile example.pyx and create two files, example.c and example.***system_info***.so
-from here run setup everytime source code is altered
-can be used from regular python from here with "import example" and "example.exampleFunc()"
