import sympy as sym
import math
import random
import numpy as np
import json

def create_polynomial(polyString,inVars):
    polyNamespace = {}
    exec("import sympy as sym", polyNamespace)    
    varList = []
    cList = []
    kList = []
    
    for varNameString in inVars:
        exec("c%s = sym.Symbol('c%s')" % (varNameString,varNameString,), polyNamespace)
        exec("k%s = sym.Symbol('k%s')" % (varNameString,varNameString,), polyNamespace)
        varList.append("c%s" % (varNameString,))
        varList.append("k%s" % (varNameString,))
        cList.append("c%s" % (varNameString,))
        kList.append("k%s" % (varNameString,))
        exec("%s = c%s - k%s" % (varNameString,varNameString,varNameString,), polyNamespace)  # plaintext integer
    
    exec('f='+polyString, polyNamespace)  # plaintext integer
    
    return {'namespace':polyNamespace,'varList':varList,'cList':cList,'kList':kList}

def flatten_nested(nestedTuple,length):
    endList = []
    remain = nestedTuple
    while len(endList)<length:
        new = []
        for t in remain:
            if isinstance(t,int):
                endList.append(t)
            else:
                new = new + list(t)
        remain = new
    return endList

from itertools import product
def all_partial_degrees(maxDegree,nVars):
    if nVars==1:
        for t in range(maxDegree+1):
            yield [t]
    else:
        baseProduct = range(maxDegree+1)
        nVars-=1
        for i in range(nVars):
            baseProduct = product(range(maxDegree+1),baseProduct)
        for t in baseProduct:
            flattenedT = flatten_nested(t,nVars)
            if(sum(flattenedT)<=maxDegree):
                yield flattenedT

def term_count(n,d):
    return int(sum([math.factorial(dd+n-1)/( math.factorial(dd) * math.factorial(n-1)) for dd in range(d+1)]))

def compute_polynomial(polynKey,indicesTupleList,cipherTupleList,polyn):
    #deserialize and reformat our key
    formattedKey = json.loads(polynKey[0]['keyJSON'])['monomialData']
    #list of client side ciphertext variables, need a count
    cipherVars = polyn['cList']
    numberOfVars = len(cipherVars)
    #get the total degree of f
    f = polyn['namespace']['f']
    degree = sym.Poly(f).total_degree()
    
    values = []
    for fiber in zip(indicesTupleList,cipherTupleList):
        position=0
        currentIndices = fiber[0]
        currentCiphertext = fiber[1]
        currentKeyData = formattedKey[','.join([str(t) for t in currentIndices] )]
        cipherMonomials = {}
        cipherMonomialStrings = []
        for exponentTuple in all_partial_degrees(degree,numberOfVars):
            #print('\n',exponentTuple,currentKeyData,currentCiphertext)
            monomial = 1
            cipherMonomialString = ''
            for i in range(len(exponentTuple)):
                exponent = exponentTuple[i]
                #construct a dictionary key for the current monomial
                currentVar = cipherVars[i]
                cipherMonomialString = cipherMonomialString + currentVar*exponent
                #take appropriate power of the derivative
                monomial = monomial*(currentCiphertext[i]**exponent)
            cipherMonomials[cipherMonomialString] = monomial
            cipherMonomialStrings.append(cipherMonomialString)

        values.append(sum([currentKeyData[monString]*cipherMonomials[monString] for monString in cipherMonomialStrings]))
        
    return values