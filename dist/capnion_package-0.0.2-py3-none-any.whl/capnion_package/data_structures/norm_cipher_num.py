# basic modules
import numpy as np
import pandas as pd
import json
from sqlalchemy import *

#a tapas of additional scientific computing 
from scipy.spatial import distance

#capnion submodules

from ..encoding import *
from ..ciphertext import *
from ..num_theory_toolbox import *
from ..db_toolbox import *
from ..polynomial import *

class NormCipherNum:
    def __init__(self, apiContext,cipher,index=False,fromPlain=False):
        
        if fromPlain == True:
            #in this scenario cipher is actually a plaintext integer
            #register data
            myKeyLoc = apiContext.get('/state/?length=1')
            
            #determine key boundaries
            dataBoundary = [myKeyLoc[0]['minId'],myKeyLoc[0]['maxId']]
            
            #create appropriate permissions
            encPerm = {'encrypt':dataBoundary}
            apiContext.post('/keys/',{"assigned_user":apiContext.userId,"keyJSON":json.dumps(encPerm)} )
            
            #pull enc key and encrypt
            myKeyGenerator = encryption_key(apiContext,dataBoundary,htmlDebug=False,seedString=False)
            keyData = []
    
            for atom in myKeyGenerator:
                keyData.append(atom['atom_key'])
                
                
            #final addition step
            self.cipher = cipher + keyData[0]
            self.index = dataBoundary[0]
            
                                      
        else:
                                      
            self.cipher = cipher
            self.index = index      
        
        self.apiContext = apiContext

        
    def __len__(self):
        return 1
        
    def __str__(self):
        return True
    
    def __hash__(self):
        return sum([(t**2 % 10000) for t in cipherList]) % 10000
    
    def __add__(self, other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x + y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x + y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return NormCipherNum(self.apiContext,ans,fromPlain=True)
    
    def __sub__(self, other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x - y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x - y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return NormCipherNum(self.apiContext,ans,fromPlain=True)
    
    
    def __mul__(self, other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x * y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x * y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return NormCipherNum(self.apiContext,ans,fromPlain=True)
    
    def __pow__(self, other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x ** y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x ** y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return NormCipherNum(self.apiContext,ans,fromPlain=True)

    #this functions well but is not actually homomorphic
    def __lt__(self,other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x - y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x - y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return ans < 0
    
    def __le__(self,other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x - y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x - y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return ans <= 0
    
    def __gt__(self,other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x - y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x - y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return ans > 0
    
    def __ge__(self,other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x - y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x - y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return ans >= 0
        
    def __eq__(self, other): 
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x - y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x - y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return ans == 0
    
    def __ne__(self, other):
        myIndices = [(self.index,other.index,),]
        cipherPair = [[self.cipher,other.cipher]]
        
        myPoly = create_polynomial('x - y', ['x','y'])
        myKey = polyn_comp_key(self.apiContext,'x - y',['x','y'],myIndices,0)
        ans = compute_polynomial(myKey, myIndices, cipherPair, myPoly)[0]
        
        return ans != 0
    
    def decrypt(self):
        decryptKeyDict = {t['id']:t['atom_key'] for t in decryption_key(
            self.apiContext,
            json.dumps([self.index])
        )}
        decryptKey = decryptKeyDict[self.index]
        return self.cipher - decryptKey
    
    def ciphertext(self,encodeList = False):
        
        return encode_ciphertext([self.cipher],encodeList)

